# Adblock Blocker Unblock

Esta extensão remove o bloqueador de AdBlocks dos sites da Abril (Veja, Exame).

Assim:

![Bloqueador de AdBlock da Abril](https://raw.githubusercontent.com/guilhermemarconi/adblock-blocker-unblock/master/bloqueando-adblock.png "Bloqueador de AdBlock da Abril")

Fica assim:

![Desbloqueado](https://raw.githubusercontent.com/guilhermemarconi/adblock-blocker-unblock/master/desbloqueado.png "Desbloqueado")

## Contribuindo

Fork, Code, Pull Request. :wink:
